//package com.nts_ed.ks.controller;
//
//import javax.annotation.PostConstruct;
//import javax.persistence.EntityManager;
//import javax.persistence.PersistenceContext;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.validation.BindingResult;
//import org.springframework.validation.annotation.Validated;
//import org.springframework.web.bind.annotation.ModelAttribute;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.servlet.ModelAndView;
//
//import com.nts_ed.ks.dao.Attendance;
//import com.nts_ed.ks.dao.AttendanceInfo;
//import com.nts_ed.ks.dao.EmployeeDao;
//import com.nts_ed.ks.dao.EmployeeService;
//import com.nts_ed.ks.entity.Employee;
//import com.nts_ed.ks.repository.EmployeeRepository;
//
//@Controller
//public class EmployeeController {
//	
//	@Autowired
//	private EmployeeService service;
//
//	
//	
//	
//	//Repositoryインターフェースを自動化インスタンス
//	@Autowired
//	private EmployeeRepository  t_attendance;
//	
//	//EntityManager自動化インスタンス化
//	@PersistenceContext
//	private EntityManager entityManager;
//	
//	//DAO自動化インスタンス化
//	@Autowired
//	private EmployeeDao employeeDao;
//	
//	@PostConstruct
//	public void init() {
//		employeeDao = new EmployeeDao();
//	}
//		
//	
//	
//	
//	
//	
//	//月を押下して勤怠情報を出したい IDとか紐づけたい
//@RequestMapping("/login/attendance/month")
//public ModelAndView attendanceInfo(@ModelAttribute AttendanceInfo attendanceInfo ,
//		ModelAndView mav) {
//	
//	//Viewに返す変数をModelに収納
//	mav.addObject("AttendanceInfo", attendanceInfo);
//	
//	//画面に出力するViewを指定
//	mav.setViewName("AttendanceInfo");
//	//ModelとView情報を返す
//	return mav;
//	
//}
//	
//	
//	//作成ボタンで勤怠作成
//	
//	@RequestMapping("/login/attendance/month/daywork")
//	public ModelAndView attendanceRegister(@ModelAttribute Attendance attendance, ModelAndView mav) {
//		
//		//Viewに返す変数をModelに収納
//		mav.addObject("Attendance", attendance);
//		
//		//画面に出力するViewを指定
//		mav.setViewName("AttendanceRegister");
//		//ModelとView情報を返す
//		return mav;
//		
//	}
//	
//	
//	
//	/*
//	 * 「"/login/attendance/month/daywork"」へPOST送信された場合
//	 * */
//	@RequestMapping(value ="/login/attendance/month/daywork",method = RequestMethod.POST)
//	//POSTデータをRegisterインスタンスとして受け入れる
//	public ModelAndView attendanceRegisterPost(@ModelAttribute @Validated Attendance attendance,
//			BindingResult result,ModelAndView mav) {
//		//入力エラーがある場合
//		if(result.hasErrors()) {
//			//エラーメッセージ
//			mav.addObject("message","入力内容に誤りがあります");
//			
//			//画面に出力するViewを指定
//			mav.setViewName("AttendanceRegister");
//			
//			//ModelとView情報を返す
//			return mav;
//		}
//		
//		
//		//入力されたデータをDBに保存
//		t_attendance.saveAndFlush(attendance);
//				
//		//リダイレクト先を指定
//		mav = new ModelAndView("redirect:/login/attendance/month");
//		//フォワードの場合もやり方は同じです（“forward:○○”）。（○○は遷移先のURL）
//		//ModelとView情報を返す
//		return mav;
//	}
//		
//		
//
//}
