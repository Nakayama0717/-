package com.nts_ed.ks.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nts_ed.ks.dao.AttendanceRegister;
import com.nts_ed.ks.entity.Attendance;

public interface AttendanceRepository extends JpaRepository<Attendance, String> {

	void saveAndFlush(AttendanceRegister attendanceRegister);

}
