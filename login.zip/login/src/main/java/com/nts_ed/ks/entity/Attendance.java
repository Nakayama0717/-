package com.nts_ed.ks.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;


//勤怠登録するファイル
@Data
@Entity
@Table(name = "t_attendance")
public class Attendance implements Serializable{
	@Id
	
//	@JoinColumn(name = "EMPLOYEE_ID")
//	@ManyToOne
	private String ATTENDANCE_ID;
	
	@Column(length =10)
	private String ATTENDANCE_DATE;
	private String START_TIME;
	private String END_TIME;
	private String REST_HOURS;
	private String WORKING_HOURS;//
	private String OVERTIME_HOURS;//
	private String ABSENCE_HOURS;
	private String STATUS_ID;
	
	private String REMARKS;
	
	private String DEL_FLG;
	private String COMMENT;//管理者の備考
	private Date   CREATE_DATE;
	private String CREATE_USER;
	private Date   UPDATE_DATE;
	private String UPDATE_USER;

	
}
