package com.nts_ed.ks.dao;




import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import lombok.Data;


//勤怠登録するファイル
@Data
@Entity
@Table(name = "t_attendance")
public class AttendanceRegister {
	
//	@GeneratedValue(strategy = GenerationType.IDENTITY)

//	@ManyToOne(fetch = FetchType.LAZY)
	@Id
	private Long ATTENDANCE_ID;
	private String  ATTENDANCE_DATE;
	@NotBlank(message = "作業開始時間は必要です。")
	private String START_TIME;
	@NotBlank(message = "作業終了時間は必要です。")
	private String END_TIME;
	private String REST_HOURS;
	private String WORKING_HOURS;//
	private String OVERTIME_HOURS;//
	private String ABSENCE_HOURS;
	private String STATUS_ID;
	
	private String REMARKS;
	
	private String DEL_FLG;
	private String COMMENT;//管理者の備考
	private Date   CREATE_DATE;
	private String CREATE_USER;
	private Date   UPDATE_DATE;
	private String UPDATE_USER;
}

	