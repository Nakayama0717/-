package com.nts_ed.ks.controller;


import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.nts_ed.ks.dao.AttendanceInfo;
import com.nts_ed.ks.dao.AttendanceRegister;
import com.nts_ed.ks.dao.Calender;
import com.nts_ed.ks.dao.EmployeeDao;
import com.nts_ed.ks.dao.EmployeeService;
import com.nts_ed.ks.entity.Attendance;
import com.nts_ed.ks.entity.Employee;
import com.nts_ed.ks.repository.AttendanceRepository;
import com.nts_ed.ks.repository.EmployeeRepository;



@Controller
public class LoginController {
	
	
	@Autowired
	private HttpSession session;
	
	@Autowired
	private EmployeeService service;

	@Autowired
	private Calender calender;
	
	
	
	//Repositoryインターフェースを自動化インスタンス
	@Autowired
	private EmployeeRepository  t_employee;
	
	@Autowired
	private AttendanceRepository  t_attendance;
	
	//EntityManager自動化インスタンス化
	@PersistenceContext
	private EntityManager entityManager;
	
	//DAO自動化インスタンス化
	@Autowired
	private EmployeeDao employeeDao;//Employee_IDで検索するクラス
	
	
	
//	@PostConstruct
//	public void init() {
//		employeeDao = new EmployeeDao();
//	}
		
		
	/*
	 * 「/login」へアクセスした場合
	 * */	
	@GetMapping(path = "/")
	public String getLogin() {
		//login.htmlに画面遷移
		return "Login";
	}

	
	@PostMapping("/login/attendance")
	public String postAttendanceRequest(@RequestParam("Attendance")
	String EMPLOYEE_ID, Model model) {//,String PASSWORD
		
		
		//1件検索
		Employee employee = service.getEmployee(EMPLOYEE_ID);//,PASSWORD
		
		//検索結果をModelに登録 右employee1がID・名前・所属が代入されている
		
		model.addAttribute("employee",employee);
		
		
		session.setAttribute("employee", employee);//("data", "保存したいデータ")
		
		
		//カレンダーのファイル参照
//		ArrayList<Integer> months = calender.getMonths();
		
		
//		model.addAttribute("months",months);
		//attendanceに１２ヶ月分繰り返し作成
		
		//Attendance.htmlに画面遷移
		return "Attendance";
	}
	
	
	
	
	
	
	
	
	
//月を押下して勤怠情報を出したい IDとか紐づけたい
@RequestMapping("/login/attendance/oddmonth")
public ModelAndView attendanceInfoOdd(
		@ModelAttribute AttendanceInfo attendanceInfo,
		ModelAndView mav) {
	
	
	Iterable<Attendance>attendanceinfo = t_attendance.findAll();//出勤情報
	
	
	//Viewに返す変数をModelに収納
	mav.addObject("attendanceinfo", attendanceinfo);
	
	
	
	//カレンダーのファイル参照
	//1.3.5.6.8.10.12月31日分
	ArrayList<Integer> odddays = calender.getOdddays();
	mav.addObject("odddays",odddays);
	
	
	Object employee = session.getAttribute("employee"); 
	mav.addObject("employee",employee);//ID　名前　所属　表示できる
	
	//画面に出力するViewを指定
	mav.setViewName("AttendanceInfoOdd");//"AttendanceInfo"html
	//ModelとView情報を返す
	return mav;
	
}
//月を押下して勤怠情報を出したい IDとか紐づけたい
@RequestMapping("/login/attendance/febmonth")
public ModelAndView attendanceInfoFeb(@ModelAttribute AttendanceInfo attendanceInfo,
		ModelAndView mav) {
	
	
	
	Iterable<Attendance>attendanceinfo = t_attendance.findAll();
	
	
	//Viewに返す変数をModelに収納
	mav.addObject("attendanceinfo", attendanceinfo);
	
	
	
	Object employee = session.getAttribute("employee"); 
	mav.addObject("employee",employee);//ID　名前　所属　表示できる
	
	
	
	//2月分28日分
	ArrayList<Integer> febdays = calender.getFebdays();
	mav.addObject("febdays",febdays);
	
	
	//画面に出力するViewを指定
	mav.setViewName("AttendanceInfoFeb");//"AttendanceInfo"html
	//ModelとView情報を返す
	return mav;
	
}
//月を押下して勤怠情報を出したい IDとか紐づけたい
@RequestMapping("/login/attendance/evenmonth")
public ModelAndView attendanceInfoEven(@ModelAttribute AttendanceInfo attendanceInfo,
		ModelAndView mav) {
	
	
	
	Iterable<Attendance>attendanceinfo = t_attendance.findAll();
	
	
	//Viewに返す変数をModelに収納
	mav.addObject("attendanceinfo", attendanceinfo);
	
	
	
	
	//4.7.9.11月30日分
	ArrayList<Integer> evendays = calender.getEvendays();
	mav.addObject("evendays",evendays);
	
	
	
	
	Object employee = session.getAttribute("employee"); 
	mav.addObject("employee",employee);//ID　名前　所属　表示できる
	
	
	
	//画面に出力するViewを指定
	mav.setViewName("AttendanceInfoEven");//"AttendanceInfo"html
	//ModelとView情報を返す
	return mav;
	
}

	
	
	//作成ボタンで勤怠作成
	
	@RequestMapping("/login/attendance/daywork")
	public ModelAndView attendanceRegister(@ModelAttribute AttendanceRegister attendanceRegister, ModelAndView mav) {
		
		//Viewに返す変数をModelに収納
		mav.addObject("AttendanceRegister", attendanceRegister);
		
		
		
		Object employee = session.getAttribute("employee"); 
		mav.addObject("employee",employee);//ID　名前　所属　表示できる
		
		
		
		//画面に出力するViewを指定
		mav.setViewName("AttendanceRegister");
		//ModelとView情報を返す
		return mav;
		
	}
	
	
	
	/*
	 * 「"/login/attendance/month/daywork"」へPOST送信された場合
	 * */
	@RequestMapping(value ="/login/attendance/daywork",method = RequestMethod.POST)
	//POSTデータをRegisterインスタンスとして受け入れる
	public ModelAndView attendanceRegisterPost(@ModelAttribute @Validated AttendanceRegister attendanceRegister,
			BindingResult result,ModelAndView mav) {
		
		Object employee = session.getAttribute("employee"); 
		mav.addObject("employee",employee);//ID　名前　所属　表示できる
		
		
		//入力エラーがある場合
		
		if(result.hasErrors()) {
			//エラーメッセージ
			mav.addObject("message","入力内容に誤りがあります");
			
			//画面に出力するViewを指定
			mav.setViewName("AttendanceRegister");
			
			//ModelとView情報を返す
			return mav;
		}
		
		
		//入力されたデータをDBに保存
		t_attendance.saveAndFlush(attendanceRegister);
				
		//リダイレクト先を指定
		mav = new ModelAndView("redirect:/login/attendance/daywork");
		//フォワードの場合もやり方は同じです（“forward:○○”）。（○○は遷移先のURL）
		//ModelとView情報を返す
		return mav;
	}
		
		



}
