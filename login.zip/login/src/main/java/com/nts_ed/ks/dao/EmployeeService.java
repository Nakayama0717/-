package com.nts_ed.ks.dao;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nts_ed.ks.entity.Employee;



@Service
public class EmployeeService {

	
	@Autowired
	private EmployeeDao repositoryDao;
	
	//社員を1人取得する

	public Employee getEmployee(String EMPLOYEE_ID){//,String PASSWORD
		//検索
		
		Map<String, Object> map =repositoryDao.findBy(EMPLOYEE_ID);//,PASSWORD
		
		//MAPから値を取得
		
		EMPLOYEE_ID=(String)map.get("EMPLOYEE_ID");
		//PASSWORD = (String)map.get("PASSWORD");
		
		String EMPLOYEE_NAME =(String)map.get("EMPLOYEE_NAME");
		String DEPT_ID =(String)map.get("DEPT_ID");
		
		
		
		//Employeeクラスに値をセット
		Employee employee = new Employee();
		
		employee.setEMPLOYEE_ID(EMPLOYEE_ID);
		//employee.setPASSWORD(PASSWORD);
		
		employee.setEMPLOYEE_NAME(EMPLOYEE_NAME);
		employee.setDEPT_ID(DEPT_ID);
		
		return employee;
		
	}
	
}
