package com.nts_ed.ks.dao;

import java.util.Map;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;






@Repository
public class EmployeeDao {

//	//エンティティマネージャー
//	private EntityManager entityManager;
//	
//	//クエリ生成用インスタンス
//	private CriteriaBuilder builder;
//	
//	//クエリ実行用インスタンス
//	private CriteriaQuery<Employee> query;
//	
//	//検索されるエンティティのルート
//	private Root<Employee> root;
//	
//	/*
//	 * コンストラクタ（DB接続準備）
//	 * */
//	public EmployeeDao(EntityManager entityManager) {
//		//EntityManager取得
//		this.entityManager = entityManager;
//		//クエリ生成用インスタンス
//		builder = entityManager.getCriteriaBuilder();
//		//クエリ実行用インスタンス
//		query = builder.createQuery(Employee.class);
//		//検索されるエンティティのルート
//		root = query.from(Employee.class);
//	}
	/*
	 * 社員検索
	 * @param String EMPLOYEE_ID
	 * @param String PASSWORD
	 * @return ArrayList<Employee>employee_list
	 * */
	
	
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public Map<String, Object> findBy(String EMPLOYEE_ID){//,String PASSWORD
		
		//SELECT句設定
		String query="SELECT*"
				+ " FROM t_employee"
				+ " WHERE EMPLOYEE_ID=? ";//AND PASSWORD=?
				
		//検索実行
		
		Map<String, Object>employee=jdbcTemplate.queryForMap(query,EMPLOYEE_ID);//, PASSWORD
		
		//クエリ実行
		return employee;
	}

	
}
