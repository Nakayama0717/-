package com.nts_ed.ks.dao;


import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.nts_ed.ks.entity.Employee;




@Repository
public class EmployeeDao {

	//エンティティマネージャー
	private EntityManager entityManager;
	
	//クエリ生成用インスタンス
	private CriteriaBuilder builder;
	
	//クエリ実行用インスタンス
	private CriteriaQuery<Employee> query;
	
	//検索されるエンティティのルート
	private Root<Employee> root;
	
	/*
	 * コンストラクタ（DB接続準備）
	 * */
	public EmployeeDao(EntityManager entityManager) {
		//EntityManager取得
		this.entityManager = entityManager;
		//クエリ生成用インスタンス
		builder = entityManager.getCriteriaBuilder();
		//クエリ実行用インスタンス
		query = builder.createQuery(Employee.class);
		//検索されるエンティティのルート
		root = query.from(Employee.class);
	}
	/*
	 * 社員検索
	 * @param String EMPLOYEE_ID
	 * @param String DEPT_ID
	 * @param String JOINING
	 * @return ArrayList<Employee>employee_list
	 * */
	
	public ArrayList<Employee> find(String EMPLOYEE_ID,String DEPT_ID,String JOINING){
		//SELECT句設定
		query.select(root);
		//WHERE句設定
		query.where(
				builder.like(root.get("EMPLOYEE_ID"),"%" +  EMPLOYEE_ID + "%" ),
				builder.like(root.get("DEPT_ID"), "%" + DEPT_ID + "%" ),
				builder.like(root.get("JOINING"), "%" + JOINING + "%")
				
		);
		//クエリ実行
		return(ArrayList<Employee>)entityManager.createQuery(query).getResultList();
		}
		
	}
