package com.nts_ed.ks.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nts_ed.ks.dao.Register;
import com.nts_ed.ks.entity.Employee;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, String> {

	void saveAndFlush(Register register);
	
}
