package com.nts_ed.ks.controller;


import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.nts_ed.ks.dao.EmployeeDao;
import com.nts_ed.ks.entity.Employee;
import com.nts_ed.ks.repository.EmployeeRepository;



@Controller
public class AdministerController {

	
	//Repositoryインターフェースを自動化インスタンス
	@Autowired
	private EmployeeRepository  t_employee;
	
	//EntityManager自動化インスタンス化
	@PersistenceContext
	private EntityManager entityManager;
	
	//DAO自動化インスタンス化
	@Autowired
	private EmployeeDao employeeDao;
	
	@PostConstruct
	public void init() {
		employeeDao = new EmployeeDao(entityManager);
	}
	
	

	//Repository t_employee;
	
	/*
	 * 「/Administer」へアクセスがあった場合
	 * 
	 * */
	
	@RequestMapping("/administer")
	public ModelAndView list(ModelAndView mav) {
		//t_employeeテーブルから全件取得
		Iterable<Employee> employee_list = t_employee.findAll();
		
		//Viewに渡す変数をModelに格納
		mav.addObject("employee_list",employee_list);
		
		//画面に出力するViewを指定
		mav.setViewName("Administer");
		
		//ModelとView情報を返す
		return mav;
	}
	
	/*
	 * 「/search」へアクセスがあった場合
	 * */
	@RequestMapping("/search")
	public ModelAndView search(HttpServletRequest request,ModelAndView mav) {
		//T_EMPLOYEEテーブルから検索
		Iterable<Employee> employee_list = employeeDao.find(
				request.getParameter("EMPLOYEE_ID"),
				request.getParameter("DEPT_ID"),
				request.getParameter("JOINING")
				
		);
		
		//Viewに渡す変数をModelに格納
		mav.addObject("employee_list", employee_list);
		
		//画面に出力するViewを指定
		mav.setViewName("Administer");
		
		//ModelとView情報を返す
		return mav;
		
	}
	
}
