package com.nts_ed.ks.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "t_employee")
public class Employee {
	@Id
	//これが初期登録されるテーブル
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	private String EMPLOYEE_ID;
	
	private String EMPLOYEE_NAME;
	
	private String PASSWORD;
	
	private String GENDER;
	
	private String AGE;
	
	private String DEPT_ID;
	
	private String JOINING;
	
	private String MAIL_ADDRESS;
	
	private String DEL_FLG;
	private String CREATE_USER;
	private Date CREATE_DATE;
	private Date UPDATE_DATE;
	private String UPDATE_USER;

	
}